#In this version I added the kwic function itself
def kwic(mystr):
	return []
