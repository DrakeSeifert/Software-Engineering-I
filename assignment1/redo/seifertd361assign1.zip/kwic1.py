#I added the end format of the kwic function to be returned
def kwic(mystr):

	endResult = ([([mystr],0)])

	return endResult
