#I added the ability to split the string by line
def kwic(mystr):

	#split string by line, returns list of sentences
	splitline = mystr.split('\n')

	endResult = ([(splitline,0)])

	return endResult
