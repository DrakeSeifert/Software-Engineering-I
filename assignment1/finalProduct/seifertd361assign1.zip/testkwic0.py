import kwic

mystr = ""
assert(kwic.kwic(mystr) == [])
