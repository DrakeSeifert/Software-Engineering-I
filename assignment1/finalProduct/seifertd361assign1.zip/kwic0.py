def kwic(mystr):
	return []
