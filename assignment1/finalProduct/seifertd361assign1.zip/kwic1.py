def kwic(mystr):

	return [mystr]
