def kwic(mystr):
	splitline = mystr.split('\n')

	return splitline
