import kwic

mystr = "z"
#assert(kwic0.kwic(mystr) == [])
assert(kwic.kwic(mystr) == [mystr])
