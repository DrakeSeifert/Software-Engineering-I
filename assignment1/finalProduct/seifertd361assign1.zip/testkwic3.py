import kwic


mystr = "hello world\nmy test\napples oranges"
#asseirt(kwic0.kwic(mystr) == [])
#assert(kwic1.kwic(mystr) == [mystr])
#assert(len(kwic3.kwic(mystr))==2)
assert len(kwic.kwic(mystr)) == 3
